import React, {useState, useEffect} from 'react';
import {Text, StyleSheet, View, FlatList, TouchableHighlight, TouchableWithoutFeedback, Keyboard, Platform} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Form from './components/Form';
import Reserva from './components/Reserva';

const App = () => {
  const [reservas, setReservas] = useState([]);
  const [mostrarForm, guardarMostrarForm]= useState(false);

  useEffect(() => {
    const obtenerReservasStorage = async () => {
      try{
        const reservasStorage = await AsyncStorage.getItem('reservas');
        if(reservasStorage){
          setReservas(JSON.parse(reservasStorage));
        }
      }catch(error){
        console.log(error);
      }
    }
    obtenerReservasStorage();
  },[]);

  const eliminarReserva = id => {
    const reservasFiltradas = reservas.filter(reserva => reserva.id !== id);
    setReservas(reservasFiltradas);
    guardarReservasStorage(JSON.stringify(reservasFiltradas));
  }

  const mostrarFormulario = () => {
    guardarMostrarForm(!mostrarForm);
  }

  const cerrarTeclado = () => {
    Keyboard.dismiss();
  }

  const guardarReservasStorage = async (citasJSON) => {
    try{
      await AsyncStorage.setItem('reservas',citasJSON);
    }catch(error){
      console.log(error);
    }
  }

  return(
    <TouchableWithoutFeedback onPress={() => cerrarTeclado()}>
      <View>
        <Text style={styles.Title}>Administrador de Reservas</Text>
        <View>
          <TouchableHighlight
            onPress={() => mostrarFormulario()}
            style={styles.buttonContainer}>
            <Text style={styles.buttonText}>
              {mostrarForm ? 'Cancelar Crear Reserva':'Crear Nueva Reserva'}
            </Text>
          </TouchableHighlight>
        </View>

        <View>
          {mostrarForm ? (
            <>
              <Text style={styles.Title2}>Crear Nueva Reserva</Text>
              <Form
                reservas={reservas}
                setReservas={setReservas}
                guardarMostrarForm={guardarMostrarForm}
                guardarReservasStorage={guardarReservasStorage}
              />
            </>
          ):(
            <>
              <Text style={styles.Title2}>
                {reservas.length > 0 ? 'Tus reservas': 'No hay reservas'}
              </Text>
              <FlatList
                data={reservas}
                renderItem={({item}) => <Reserva item={item} eliminarReserva={eliminarReserva}/>}
              />
            </>
          )}
        </View>
      </View>
    </TouchableWithoutFeedback>
  );

};

const styles = StyleSheet.create({
  Title:{
    fontSize: 22,
    margin: 'auto',
    paddingTop:50,
    paddingLeft:70,
    paddingRight:70,
    fontFamily:"Arial",
    fontWeight: 'bold'
  },
  Title2:{
    fontSize: 15,
    margin: 'auto',
    fontFamily:"Arial",
    fontWeight: 'bold',
    paddingHorizontal: 25
  },
  buttonContainer:{
    elevation: 8,
    backgroundColor:'#77C5F6',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    width:"85%",
    marginHorizontal:25,
    marginVertical: 12
  },
  buttonText:{
    fontSize: 12,
    color: "#fff",
    fontWeight: "bold",
    alignSelf: "center",
    textTransform: "uppercase"
  }
});

export default App;