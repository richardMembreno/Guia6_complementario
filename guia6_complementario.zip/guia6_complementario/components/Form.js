import React,{useState} from "react";
import {Text, StyleSheet, View, TextInput, Button, TouchableHighlight, Alert, ScrollView} from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { Picker } from '@react-native-picker/picker';
import shortid from 'react-id-generator';

const Form = ({reservas, setReservas, guardarMostrarForm, guardarReservasStorage}) => {
  const [nombre,guardarNombre] = useState('');
  const [cantidad,guardarCantidad] = useState('');
  const [seccion,guardarSeccion] = useState('');
  const [fecha,guardarFecha] = useState('');
  const [hora,guardarHora] = useState('');

  const [isDatePickerVisible,setDatePickerVisibility] = useState('');
  const [isTimePickerVisible,setTimePickerVisibility] = useState('');

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const confirmarFecha = date => {
    const opciones = {year:'numeric', month:'long', day:"2-digit"};
    guardarFecha(date.toLocaleDateString('es-SV',opciones));
    hideDatePicker();
  };

  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };

  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };

  const confirmarHora = hora => {
    const opciones = {hour:'numeric', minute:'2-digit', hour12: false};
    guardarHora(hora.toLocaleString('es-SV',opciones));
    hideTimePicker();
  };

  const crearNuevaReserva = () => {
    if(nombre.trim() === '' || cantidad.trim() === '' || seccion.trim() === '' || fecha.trim() === '' || hora.trim() === ''){
      mostrarAlerta();
      return;
    }

    const reserva = {nombre, cantidad, seccion, fecha, hora};
    reserva.id = shortid();

    const reservasNuevo = [...reservas, reserva];
    setReservas(reservasNuevo);

    guardarReservasStorage(JSON.stringify(reservasNuevo));

    guardarMostrarForm(false);

    guardarNombre('');
    guardarCantidad('');
    guardarSeccion('');
    guardarHora('');
    guardarFecha('');
  }

  const mostrarAlerta = () => {
    Alert.alert(
      'Error',
      'Todos los campos son obligatorios',
      [{
        text:'OK'
      }]
    )
  }

return(
    <>
      <ScrollView>
        <View>
          <Text style={styles.Title}>Nombre:</Text>
          <TextInput
            style={styles.input}
            onChangeText={texto => guardarNombre(texto)}/>
        </View>

        <View>
          <Text style={styles.Title}>Cantidad personas:</Text>
          <TextInput
              style={styles.input}
              onChangeText={texto => guardarCantidad(texto)}
              keyboardType='numeric'/>
        </View>

        <View>
          <Text style={styles.Title}>Sección:</Text>
          <Picker
            style={styles.input}
            selectedValue={seccion}
            onValueChange={(value) => guardarSeccion(value)}
            >
            <Picker.Item label="Fumadores" value="Fumadores" />
            <Picker.Item label="No Fumadores" value="No Fumadores" />
          </Picker>
        </View>

        <View>
          <Text style={styles.Title}>Fecha: {fecha}</Text>
          <Button title="Seleccionar Fecha"
                  onPress={showDatePicker} 
                  style={styles.buttonContainer}
          />
          <DateTimePickerModal 
            isVisible={isDatePickerVisible}
            mode="date"
            onConfirm={confirmarFecha}
            onCancel={hideDatePicker}
            local='es_SV'
            headerTextIOS="Elige la fecha"
            cancelTextIOS="Cancelar"
            confirmTextIOS="Confirmar"
          />
        </View>

        <View>
          <Text style={styles.Title}>Hora: {hora}</Text>
          <Button title="Seleccionar Hora"
                  onPress={showTimePicker}
          />
          <DateTimePickerModal 
            isVisible={isTimePickerVisible}
            mode="time"
            onConfirm={confirmarHora}
            onCancel={hideTimePicker}
            local='es_SV'
            headerTextIOS="Elige una hora"
            cancelTextIOS="Cancelar"
            confirmTextIOS="Confirmar"
          />
        </View>

        <View>
          <TouchableHighlight 
            style={styles.buttonContainer}
            onPress={() => crearNuevaReserva()}>
            <Text style={styles.buttonText}>Crear Nueva Reservacion</Text>
          </TouchableHighlight>
        </View>

      </ScrollView>
    </>
  );


};

const styles = StyleSheet.create({
  input:{
    borderColor: "gray",
    width: "90%",
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginLeft:15,
    marginRight:15,
    marginVertical:12
  },
  buttonContainer:{
    elevation: 8,
    backgroundColor:'#898EEB',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    width:"85%",
    marginHorizontal:25,
    marginVertical:20
  },
  buttonText:{
    fontSize: 15,
    color: "#fff",
    fontWeight: "bold",
    alignSelf: "center",
    textTransform: "uppercase"
  },
  Title:{
    fontSize: 15,
    margin: 'auto',
    fontFamily:"Arial",
    paddingHorizontal: 25
  }
});

export default Form;